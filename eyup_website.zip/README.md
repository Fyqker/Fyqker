# Eyüp Taşkın — Kişiye Özel Web Sitesi (10₺)
Bu repo, `index.html` (ana site) ve `bio.html` (Instagram link sayfası) dosyalarını içerir.

📩 İletişim: eyuptaskin00@gmail.com  
📸 Instagram: [@eyup_227](https://instagram.com/eyup_227)
